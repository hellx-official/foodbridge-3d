import type { Metadata, Viewport } from "next";
import localFont from "next/font/local";
import { siteConfig, siteUrl } from "@/lib/site";
import "./globals.css";

const inter = localFont({
  src: "../../public/fonts/inter-latin.woff2",
  variable: "--font-inter",
  display: "swap",
  weight: "100 900",
});
const sora = localFont({
  src: "../../public/fonts/sora-latin.woff2",
  variable: "--font-sora",
  display: "swap",
  weight: "100 800",
});

export const metadata: Metadata = {
  metadataBase: siteUrl,
  title: { default: siteConfig.title, template: "%s | FoodBridge" },
  description: siteConfig.description,
  applicationName: siteConfig.name,
  keywords: ["food rescue", "food donation", "zero waste", "restaurants", "shelters", "community"],
  openGraph: {
    type: "website",
    locale: "en_US",
    url: "/",
    siteName: siteConfig.name,
    title: "FoodBridge — Good food. Greater good.",
    description: siteConfig.description,
    images: [
      {
        url: "/opengraph-image",
        width: 1200,
        height: 630,
        alt: "FoodBridge: Rescue Food. Feed People. Zero Waste.",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "FoodBridge — Good food. Greater good.",
    description: siteConfig.description,
    images: ["/opengraph-image"],
  },
  alternates: { canonical: "/" },
  robots: { index: true, follow: true },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#FEFAE0",
  colorScheme: "light",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en" className={`${inter.variable} ${sora.variable}`}>
      <body className="font-sans">{children}</body>
    </html>
  );
}
