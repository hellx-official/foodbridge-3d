/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  poweredByHeader: false,
  // Permit the workspace's reverse-proxied development preview (production is unaffected).
  allowedDevOrigins: ["*.e2b.app"],
  // All artwork is inline SVG; fonts are self-hosted. Disable the unused image proxy.
  images: { unoptimized: true },
};

export default nextConfig;
