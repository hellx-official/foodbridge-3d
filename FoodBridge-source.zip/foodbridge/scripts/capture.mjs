// Optional visual QA: run against a local production server with `npm start`.
// Usage: node scripts/capture.mjs [http://127.0.0.1:3000]
import { chromium } from "@playwright/test";
import { mkdir } from "node:fs/promises";

const baseUrl = process.argv[2] || "http://127.0.0.1:3000";
await mkdir("artifacts", { recursive: true });
const browser = await chromium.launch();

try {
  for (const [name, width, height] of [
    ["desktop", 1440, 1000],
    ["tablet", 768, 1024],
    ["mobile", 375, 812],
  ]) {
    const context = await browser.newContext({
      viewport: { width, height },
      deviceScaleFactor: 1,
      reducedMotion: "reduce",
    });
    const page = await context.newPage();
    const errors = [];
    page.on("pageerror", (error) => errors.push(error.message));
    await page.goto(baseUrl);
    await page.locator("#live-rescues article").first().waitFor();
    await page.evaluate(() => document.fonts.ready);
    await page.screenshot({ path: `artifacts/${name}-top.png` });

    // Reveal below-the-fold sections before a full-page capture.
    await page.evaluate(async () => {
      for (let y = 0; y < document.body.scrollHeight; y += 650) {
        window.scrollTo(0, y);
        await new Promise((resolve) => setTimeout(resolve, 50));
      }
      window.scrollTo(0, 0);
    });
    await page.waitForTimeout(300);
    await page.screenshot({ path: `artifacts/${name}-full.png`, fullPage: true });
    const dimensions = await page.evaluate(() => ({
      viewport: innerWidth,
      document: document.documentElement.scrollWidth,
    }));
    if (dimensions.document > dimensions.viewport || errors.length) {
      throw new Error(
        `${name}: overflow or browser errors: ${JSON.stringify({ dimensions, errors })}`,
      );
    }
    console.log(`${name}: ${width}px capture complete; no overflow or browser errors.`);
    await context.close();
  }
} finally {
  await browser.close();
}
