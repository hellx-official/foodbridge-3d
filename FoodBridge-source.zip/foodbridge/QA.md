# FoodBridge — validation report

Validated locally on October 29, 2026.

## Environment

- Next.js 16.4.3, React 19.3.1, Tailwind CSS 4.3.3
- Node.js 20.20.2 in the build workspace; Node.js 22 recommended for deployment
- Playwright 1.64.1 / Chromium 156
- axe-core 4.11.1

## Results

| Check                                               | Result                                                                   |
| --------------------------------------------------- | ------------------------------------------------------------------------ |
| Clean install with `npm ci`                         | Passed                                                                   |
| Production build with `npm run build`               | Passed; home and metadata routes prerendered                             |
| TypeScript with `npm run typecheck`                 | Passed                                                                   |
| ESLint with `npm run lint`                          | Passed; no warnings or errors                                            |
| Formatting with `npm run format:check`              | Passed                                                                   |
| Dependency audit with `npm audit --audit-level=low` | Zero reported vulnerabilities at validation time                         |
| Playwright end-to-end suite                         | 9 of 9 passed                                                            |
| 375px mobile layout                                 | No horizontal overflow or browser errors                                 |
| 768px tablet layout                                 | No horizontal overflow or browser errors                                 |
| 1440px desktop layout                               | No horizontal overflow or browser errors                                 |
| 1920px wide layout                                  | No horizontal overflow in interaction tests                              |
| Automated WCAG A/AA checks                          | No violations in tested page states at 375, 768, 1440, and 1920px        |
| Restaurant dialog accessibility                     | No violations in tested dialog state                                     |
| Normal-motion mobile anchor navigation              | Manually exercised; no browser errors                                    |
| Responsive visual review                            | Desktop, tablet, mobile, rescue grid, impact chart, and dialogs reviewed |

## Covered interactions

- Initial rescue skeletons and loading completion
- All / Food / Drinks / Bakery filters and result counts
- Claim validation, confirmation, and claim state across category changes
- Restaurant food-listing demo
- Shelter / volunteer registration demo
- Contact validation, role selection, success state, reset, and toast dismissal
- Mobile menu open/close, Escape handling, and anchor navigation
- Back-to-top visibility, scrolling, and focus restoration
- Privacy information dialog
- Custom 404 and return navigation
- Page title, social metadata, favicon, social image, robots.txt, and sitemap.xml

## Evidence and reproduction

Screenshots are in `artifacts/`. Regenerate the primary responsive captures with:

```bash
npm run build
npm start
# In another terminal:
node scripts/capture.mjs
```

Run the full interaction and accessibility suite with `npm test` after installing the Playwright browser. See README.md for setup.

## Scope and limitations

This is an interactive frontend demo, not a live food-rescue service. Forms do not transmit data; claims do not reserve actual meals. The city, listings, impact figures, testimonials, and partners are illustrative. A real launch requires backend integration, verified content, operational food-safety procedures, and operator-specific legal policies.

Accessibility validation is automated plus visual/keyboard checks, not a certification or a substitute for testing with assistive-technology users. The audit reflects the dependency database at validation time and is not a guarantee of future security.

A Vercel account deployment was not performed; the project includes deployment configuration and was validated using a local production build.
