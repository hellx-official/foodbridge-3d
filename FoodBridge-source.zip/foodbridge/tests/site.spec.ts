import { test, expect, type Page } from "@playwright/test";
import AxeBuilder from "@axe-core/playwright";

async function openPage(page: Page) {
  await page.goto("/");
  await expect(page.getByRole("heading", { level: 1 })).toHaveText(
    "Rescue Food.Feed People.Zero Waste.",
  );
  await expect(page.getByRole("button", { name: "Claim 23 items from Bella Roma" })).toBeVisible();
}

async function fillContact(page: Page) {
  await page.getByLabel("Name", { exact: false }).fill("Jordan Green");
  await page.getByLabel("Email", { exact: false }).fill("jordan@example.com");
  await page.getByLabel("I am a", { exact: false }).click();
  await page.getByRole("option", { name: "Restaurant", exact: true }).click();
  await page
    .getByLabel("Message", { exact: false })
    .fill("We have surplus meals to share with our neighborhood.");
}

test("all sections, metadata, favicon and social image are available", async ({
  page,
  request,
}) => {
  await openPage(page);
  for (const id of [
    "home",
    "how-it-works",
    "live-rescues",
    "impact",
    "partners",
    "stories",
    "contact",
  ])
    await expect(page.locator(`#${id}`)).toBeAttached();
  await expect(page).toHaveTitle("FoodBridge — Rescue Food. Feed People. Zero Waste.");
  await expect(page.locator('meta[property="og:title"]')).toHaveAttribute("content", /FoodBridge/);
  expect((await request.get("/icon.svg")).ok()).toBeTruthy();
  const image = await request.get("/opengraph-image");
  expect(image.ok()).toBeTruthy();
  expect(image.headers()["content-type"]).toContain("image/png");
  expect((await request.get("/robots.txt")).ok()).toBeTruthy();
  expect((await request.get("/sitemap.xml")).ok()).toBeTruthy();
});

test("simulated loading and rescue filters", async ({ page }) => {
  await page.goto("/");
  await expect(page.getByText("Loading demo rescue listings")).toBeAttached();
  await expect(page.locator("#live-rescues article")).toHaveCount(6);
  await page.getByRole("button", { name: "Drinks", exact: true }).click();
  await expect(page.locator("#live-rescues article")).toHaveCount(1);
  await expect(page.getByRole("heading", { name: "Sip & Soul" })).toBeVisible();
  await page.getByRole("button", { name: "Bakery", exact: true }).click();
  await expect(page.locator("#live-rescues article")).toHaveCount(2);
  await page.getByRole("button", { name: "Food", exact: true }).click();
  await expect(page.locator("#live-rescues article")).toHaveCount(3);
  await page.getByRole("button", { name: "All Rescues", exact: true }).click();
  await expect(page.locator("#live-rescues article")).toHaveCount(6);
});

test("claim validates, confirms, and persists for this page visit", async ({ page }) => {
  await openPage(page);
  await page.getByRole("button", { name: "Claim 23 items from Bella Roma" }).click();
  const dialog = page.getByRole("dialog");
  await expect(dialog).toBeVisible();
  await dialog.getByRole("button", { name: "Confirm Demo Claim" }).click();
  await expect(dialog.getByText("Your name is required.")).toBeVisible();
  await dialog.getByLabel("Your name").fill("Jordan Green");
  await dialog.getByLabel("Email address").fill("jordan@example.com");
  await dialog.getByRole("checkbox").check();
  await dialog.getByRole("button", { name: "Confirm Demo Claim" }).click();
  await expect(dialog.getByText("Good food. Great choice.")).toBeVisible();
  await dialog.getByRole("button", { name: "Back to FoodBridge" }).click();
  await expect(
    page.getByRole("button", { name: "Bella Roma claimed in this demo" }),
  ).toBeDisabled();
  await page.getByRole("button", { name: "Food", exact: true }).click();
  await expect(
    page.getByRole("button", { name: "Bella Roma claimed in this demo" }),
  ).toBeDisabled();
});

test("restaurant listing and rescuer signup demo flows", async ({ page }) => {
  await openPage(page);
  await page.getByRole("button", { name: "I'm a Restaurant" }).click();
  let dialog = page.getByRole("dialog");
  await dialog.getByLabel("Restaurant name").fill("Test Kitchen");
  await dialog.getByLabel("Contact email").fill("chef@example.com");
  await dialog.getByLabel("What would you like to donate?").fill("20 fresh vegetarian meals");
  await dialog.getByLabel("Number of items").fill("20");
  await dialog.getByLabel("Pickup window").fill("Today, 8–10 PM");
  await dialog.getByLabel("Pickup address").fill("123 Main Street, San Francisco");
  await dialog.getByRole("button", { name: "Create Demo Listing" }).click();
  await expect(dialog.getByText("That’s food worth sharing.")).toBeVisible();
  await dialog.getByRole("button", { name: "Back to FoodBridge" }).click();
  await page.getByRole("button", { name: "Join as a Rescuer" }).click();
  dialog = page.getByRole("dialog");
  await dialog.getByLabel("Your name").fill("Jordan Green");
  await dialog.getByLabel("Email address").fill("jordan@example.com");
  await dialog.getByLabel("Your neighborhood or city").fill("San Francisco");
  await dialog.getByLabel("I am a").click();
  await page.getByRole("option", { name: "Volunteer", exact: true }).click();
  await dialog.getByRole("button", { name: "Join the Demo" }).click();
  await expect(dialog.getByText("You’re in good company.")).toBeVisible();
  await page.keyboard.press("Escape");
  await expect(page.getByRole("dialog")).toHaveCount(0);
});

test("contact validation, success, reset, and notification dismissal", async ({ page }) => {
  await openPage(page);
  await page.getByRole("button", { name: "Send Message" }).click();
  await expect(page.getByText("Please enter your name (at least 2 characters).")).toBeVisible();
  await expect(page.getByText("Please select your role.")).toBeVisible();
  await fillContact(page);
  await page.getByRole("button", { name: "Send Message" }).click();
  await expect(page.getByText("A little hello. A lot of possibility.")).toBeVisible();
  await expect(page.getByText("Thanks for reaching out!")).toBeVisible();
  await page.getByRole("button", { name: "Dismiss notification" }).click();
  await page.getByRole("button", { name: "Send another message" }).click();
  await expect(page.getByLabel("Name", { exact: false })).toHaveValue("");
});

test("mobile navigation, small-screen overflow, back-to-top", async ({ page }) => {
  await page.setViewportSize({ width: 375, height: 812 });
  await openPage(page);
  expect(
    await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth),
  ).toBeTruthy();
  const toggle = page.getByRole("button", { name: "Open navigation menu" });
  await toggle.click();
  await expect(page.getByRole("navigation", { name: "Mobile navigation" })).toBeVisible();
  await page.keyboard.press("Escape");
  await expect(toggle).toBeFocused();
  await toggle.click();
  await page
    .getByRole("navigation", { name: "Mobile navigation" })
    .getByRole("link", { name: "Impact", exact: true })
    .click();
  await expect(page).toHaveURL(/#impact$/);
  await expect(toggle).toHaveAttribute("aria-expanded", "false");
  await page.getByRole("button", { name: "Back to top" }).click();
  await expect(page.getByRole("link", { name: "FoodBridge home" }).first()).toBeFocused();
  await expect.poll(() => page.evaluate(() => window.scrollY)).toBe(0);
});

test("responsive layouts and fully revealed content pass accessibility checks", async ({
  page,
}) => {
  for (const width of [375, 768, 1440, 1920]) {
    await page.setViewportSize({ width, height: 1000 });
    await openPage(page);
    expect(
      await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth),
    ).toBeTruthy();
    // Bring every scroll-entrance section into view before checking its final contrast.
    await page.evaluate(async () => {
      for (let y = 0; y < document.body.scrollHeight; y += 650) {
        window.scrollTo(0, y);
        await new Promise((resolve) => setTimeout(resolve, 40));
      }
      window.scrollTo(0, 0);
    });
    await page.waitForTimeout(250);
    const audit = await new AxeBuilder({ page })
      .withTags(["wcag2a", "wcag2aa", "wcag21aa"])
      .analyze();
    expect(audit.violations, `Accessibility at ${width}px`).toEqual([]);
  }
});

test("automated accessibility checks for page and open dialog", async ({ page }) => {
  await openPage(page);
  const pageAudit = await new AxeBuilder({ page })
    .withTags(["wcag2a", "wcag2aa", "wcag21aa"])
    .analyze();
  expect(pageAudit.violations).toEqual([]);
  await page.getByRole("button", { name: "I'm a Restaurant" }).click();
  const dialogAudit = await new AxeBuilder({ page })
    .include('[role="dialog"]')
    .withTags(["wcag2a", "wcag2aa", "wcag21aa"])
    .analyze();
  expect(dialogAudit.violations).toEqual([]);
});

test("legal links work and a missing route has a helpful page", async ({ page }) => {
  await openPage(page);
  await page.getByRole("button", { name: "Privacy Policy", exact: true }).click();
  await expect(page.getByRole("dialog").getByText("Your privacy matters")).toBeVisible();
  await page.keyboard.press("Escape");
  await page.goto("/not-a-real-page");
  await expect(
    page.getByRole("heading", { name: "Let’s get you back to the good." }),
  ).toBeVisible();
  await page.getByRole("link", { name: "Back to FoodBridge" }).click();
  await expect(page.getByRole("heading", { level: 1 })).toContainText("Rescue Food.");
});
